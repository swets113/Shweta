from flask import Flask , jsonify
import mysql.connector
mydb=mysql.connector.connect(host="localhost" , user="root" , password="Cute@ngel123" , database= "database1")


app = Flask(__name__)

mycursor = mydb.cursor()

mycursor.execute("SELECT * FROM city")
myresult = mycursor.fetchall()

@app.route('/getdata', methods=["GET"])
def getdata():
    data = []

    for row in myresult:
        data.append(row)
        print(data)

    return jsonify(data)


app.run()
